// Demo4Doxygen.cpp : This file contains the 'main' function. Program execution begins and ends there.
//


#include <iostream>
#include "Department.h"
#include "Employee.h"
#include "Utils.h"
#include <malloc.h>
#include <fstream>
#include <string>
#include <Windows.h>
#include <shellapi.h>
#include <sqlext.h>
#include <sqltypes.h>
#include <sql.h>

using namespace std;

class cls1 {

public:
    void privatecls1();
    cls1();
    void show();
    void geometry();
};

class cls2 {
public:
    void privatecls2();
    cls2();
    void show();
};

int print1(const char* str);

void print2(int i);

void print3();

void print4();

void print5();

bool mySQLConn(string constr);

void Register(string str);