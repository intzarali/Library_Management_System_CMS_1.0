#pragma once

void DeptM();
void DeptD();