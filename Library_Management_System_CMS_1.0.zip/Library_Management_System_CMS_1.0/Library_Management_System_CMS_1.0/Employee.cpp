#include "Employee.h"
#include<iostream>
#include "SalaryPkg.h"

using namespace std;
using namespace SalCalc;
using namespace PFCalc;

void EmpSal()
{
    // calling packages functions

    SalCalc::NetSal();
    SalCalc::GrossSal();
    SalCalc::CompSal();
}
void EmpPF() {

    PFCalc::PFCalc();
    PFCalc::PFDiv();
    PFCalc::PFSum();
}

