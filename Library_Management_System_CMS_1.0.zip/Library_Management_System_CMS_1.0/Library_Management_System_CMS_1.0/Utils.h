#pragma once

#define MAX = 255;
#define MIN = 10;


float Pi(int i_var);
int area(int l, int k);
int length(int l, int k);
void hieght(int l);