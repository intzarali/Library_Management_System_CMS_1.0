// Demo4Doxygen.cpp : This file contains the 'main' function. Program execution begins and ends there.

#include "AccountMgmt.h"


int print1(const char* str) {

    std::cout << "Hello , I am print1" << str << std::endl;
    return 20;

}

void print2(int i) {

    const char* str = "CB_Analyzer";

    std::cout << "Hello , I am print2" << i << std::endl;
    int ret = print1(str);

}

void print3() {

    std::cout << "Hello , I am print3" << std::endl;
    print2(10);

}

void print4() {

    std::cout << "Hello , I am print4" << std::endl;
    print3();

}

void print5() {

    std::cout << "Hello , I am fun5 & Calling print5()" << std::endl;
    print4();
    std::cout << "Yes! fun1 function called here = " << std::endl;
    // function call from file2
    DeptM();
    DeptD();
}

bool mySQLConn(string constr)
{

    SQLHANDLE SQLeventHandle = NULL;
    SQLHANDLE SQLConnectionHandle = NULL;
    SQLHANDLE SQLStatementHandle = NULL;
    SQLHANDLE retCode = 0;

    char SQLQuery[] = "SELECT *FROM EMP";

    SQLWCHAR retConString[1024];

    switch (SQLDriverConnect(SQLConnectionHandle, NULL, (SQLWCHAR*)"DRIVER={SQL Server}; SERVER=localhost,1433;DATABASE=myDB; UID=Admin;PWD=passwd;", SQL_NTS, retConString, 1024, NULL, SQL_DRIVER_NOPROMPT))
    {
    case SQL_SUCCESS:
        break;
    default:
        std::cout << "Error in database connection!!!" << std::endl;

    }
    return 1;
}

void Register(string str) {

    // Creation of fstream class object
    fstream fio;
    str = "CB";
    bool bl = mySQLConn("str");

    fio.open("C:\\CPP_Workloads_CB_Analyzer\\Library_Management_System\\sample.txt", ios::trunc | ios::out | ios::in);

    fio.close();
}



 void cls1:: privatecls1() {
        std::cout << "Hello, I am cls1's Private 1 !!!" << std::endl;
  }

cls1::cls1() {

        std::cout << "Hello, I am cls1's Constructor !!!" << std::endl;
 }

void cls1::show() {

    std::cout << "I am in cls1" << std::endl;
    //calling private function
    privatecls1();
}

void cls1::geometry()
{
    char* str = new char[10];
}

void cls2::privatecls2() {

    std::cout << "Hello, I am cls1's Private 2 !!!" << std::endl;
}

cls2::cls2() {

        std::cout << "Hello, I am cls2's Constructor !!!" << std::endl;
    }

void cls2::show() {

    std::cout << "I am in cls2" << std::endl;
    // calling private function
    privatecls2();
    // function call from file1
    DeptM();
}
