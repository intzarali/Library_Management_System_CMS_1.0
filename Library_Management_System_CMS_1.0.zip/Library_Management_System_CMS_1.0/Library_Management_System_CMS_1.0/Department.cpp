#include "Department.h"
#include <iostream>
#include "Utils.h"


void DeptM()
{
	int r = 0;
	std::cout << "file2_fun1" << std::endl;

	r = area(10, 20);
	r = length(10, 10);
}
void DeptD() {

	std::cout << "file2_fun2" << std::endl;

	hieght(10);

}