#pragma once

void EmpSal();
void EmpPF();