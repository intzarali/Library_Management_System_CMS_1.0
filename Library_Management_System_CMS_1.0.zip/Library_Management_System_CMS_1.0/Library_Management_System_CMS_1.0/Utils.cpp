#pragma once

float Pi(int i_var)
{
	return i_var * 3.14;
}

int area(int l, int k)
{
	return (l + k);
}

int length(int l, int k)
{
	return (l + k);
}

void hieght(int l)
{
	l = 10;
	//return l;
}