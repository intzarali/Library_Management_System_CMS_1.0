#pragma once

#include <iostream>

namespace SalCalc
{
    void NetSal()
    {
        std::cout << "|--------NetSal()-------|" << std::endl;

    }

    void GrossSal()
    {
        std::cout << "|--------GrossSal()-------|" << std::endl;

    }

    void CompSal()
    {
        std::cout << "|--------CompSal()-------|" << std::endl;

    }
}

namespace PFCalc
{
    void PFCalc()
    {
        std::cout << "|--------PFCalc()-------|" << std::endl;

    }

    void PFDiv()
    {
        std::cout << "|--------PFDiv()-------|" << std::endl;

    }

    void PFSum()
    {
        std::cout << "|--------PFSum()-------|" << std::endl;

    }
}