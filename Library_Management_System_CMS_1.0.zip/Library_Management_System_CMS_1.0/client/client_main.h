/*
* client_main.h
* Server program for managing clients requests, settings etc.
*/


int client();